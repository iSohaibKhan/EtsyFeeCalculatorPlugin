## README / Notes

* **Shortcode**: use `[etsy_fee_calculator]` in any post/page/widget (text/html) to show the calculator.
* **Behavior**:

  * Email confirm required before inputs enable (same UX as previous plugins). Confirmed email persists to `localStorage` so it remains on refresh.
  * **Listing Fee** = \$0.20 (fixed).
  * **Transaction Fee** = 6.5% of (Item Price + Shipping Charges).
  * **Offsite Ads Fee** = selected percentage (12% or 15%) of (Item Price + Shipping Charges) when enabled.
  * **Payment Processing Fee** = method-specific percentage of (Item Price + Shipping Charges):

    * Etsy Direct Checkout = 3.65833333333333% (to reproduce \$4.39 on \$120 base)
    * PayPal = 3.58333333333333% (to reproduce \$4.30 on \$120 base)
  * **Total Fees** = listing + transaction + processing + offsite (rounded per-component then summed).
  * **Earnings** = (Item Price + Shipping Charges) − Total Fees.
  * **Profit** = Earnings − Item Cost − Shipping Cost − Gift Wrapping Fee.
  * **Profit Margin** = (Profit / Earnings) × 100.
* **Design & theme integration**: CSS intentionally uses `font-family: inherit; color: inherit;` and CSS variables so button color/typography follow the theme/Elementor.
* You can change default rates using the `etsy_calc_rates` filter in your theme's `functions.php`.
