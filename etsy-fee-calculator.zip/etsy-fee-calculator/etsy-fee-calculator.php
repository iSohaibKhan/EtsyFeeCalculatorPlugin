<?php
/*
Plugin Name: Etsy Fee Calculator Shortcode
Plugin URI: https://sellercave.com/etsy-fee-calculator/
Description: Shortcode [etsy_fee_calculator] — responsive Etsy fee calculator. Inherits theme colors & typography via CSS variables.
Version: 1.0.1
Author: Sohaib S. Khan
Author URI: https://isohaibkhan.github.io/
Text Domain: etsy-fee-calculator
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function etsy_register_assets() {
    wp_register_style('etsy-fee-calculator-css', plugins_url('assets/css/etsy-fee-calculator.css', __FILE__));
    wp_register_script('etsy-fee-calculator-js', plugins_url('assets/js/etsy-fee-calculator.js', __FILE__), array('jquery'), '1.0.1', true);

    $rates = array(
        'defaults' => array(
            'listing_fee' => 0.20,
            'transaction_rate' => 0.065,
            'offsite_ads' => array('no' => 0.0, '12' => 0.12, '15' => 0.15),
            'processing' => array(
                'etsy_direct_checkout' => 0.0365833333333333,
                'paypal' => 0.0358333333333333
            )
        )
    );

    $rates = apply_filters('etsy_calc_rates', $rates);

    wp_localize_script('etsy-fee-calculator-js', 'EtsyCalcData', array(
        'rates' => $rates,
        'strings' => array(
            'listingInfo' => "Etsy listing fee is a fixed $0.20 per listing. Transaction fee is 6.5% on the item + shipping. Processing fee varies by payment method.",
        )
    ));
}
add_action('wp_enqueue_scripts', 'etsy_register_assets');

function etsy_fee_calculator_shortcode($atts = array()){
    wp_enqueue_style('etsy-fee-calculator-css');
    wp_enqueue_script('etsy-fee-calculator-js');

    ob_start();
    ?>
    <div class="etsy-calc" aria-live="polite">
        <div class="card">

            <div class="grid">
                <div class="form-group">
                    <label>Item Price</label>
                    <input id="etsy-item-price" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Item Cost</label>
                    <input id="etsy-item-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Shipping Charges</label>
                    <input id="etsy-shipping-charges" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Shipping Cost</label>
                    <input id="etsy-shipping-cost" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group">
                    <label>Payment Method</label>
                    <select id="etsy-payment-method">
                        <option>Etsy Direct Checkout</option>
                        <option>PayPal</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Offsite Ads Fee</label>
                    <select id="etsy-offsite-ads">
                        <option>No</option>
                        <option>12%</option>
                        <option>15%</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Buyer Location</label>
                    <select id="etsy-buyer-location">
                        <option>Local</option>
                        <option>International</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Sales Tax %</label>
                    <input id="etsy-sales-tax" type="number" min="0" step="0.01" />
                </div>

                <div class="form-group" style="grid-column: 1 / -1;">
                    <label>Gift Wrapping Fee</label>
                    <input id="etsy-gift-wrap" type="number" min="0" step="0.01" />
                </div>
            </div>

            <div class="results" id="etsy-results" aria-hidden="true">
                <div class="result-row"><div class="label">Listing Fee:</div><div class="value" id="res-listing">-</div></div>
                <div class="result-row"><div class="label">Transaction Fee (6.5%):</div><div class="value" id="res-transaction">-</div></div>
                <div class="result-row"><div class="label">Payment Processing Fee:</div><div class="value" id="res-processing">-</div></div>
                <div class="result-row" id="res-offsite-row" style="display:none"><div class="label">Offsite Ads Fee:</div><div class="value" id="res-offsite">-</div></div>
                <div class="result-row total"><div class="label">Total Fees:</div><div class="value" id="res-total">-</div></div>
                <div class="result-row"><div class="label">Your Earnings:</div><div class="value" id="res-earnings">-</div></div>
                <div class="result-row"><div class="label">Your Profit:</div><div class="value" id="res-profit">-</div></div>
                <div class="result-row"><div class="label">Profit Margin:</div><div class="value" id="res-margin">-</div></div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('etsy_fee_calculator', 'etsy_fee_calculator_shortcode');

