(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var data = (window.EtsyCalcData && window.EtsyCalcData.rates) ? window.EtsyCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.etsy-calc');
        if(!root) return;

        var email = qs('#etsy-email', root);
        var confirmBtn = qs('#etsy-confirm-email', root);
        var clearBtn = qs('#etsy-clear', root);

        var inputs = [
            qs('#etsy-item-price', root),
            qs('#etsy-item-cost', root),
            qs('#etsy-shipping-charges', root),
            qs('#etsy-shipping-cost', root),
            qs('#etsy-payment-method', root),
            qs('#etsy-offsite-ads', root),
            qs('#etsy-buyer-location', root),
            qs('#etsy-sales-tax', root),
            qs('#etsy-gift-wrap', root)
        ];

        var results = qs('#etsy-results', root);
        var resListing = qs('#res-listing', root);
        var resTransaction = qs('#res-transaction', root);
        var resProcessing = qs('#res-processing', root);
        var resOffsiteRow = qs('#res-offsite-row', root);
        var resOffsite = qs('#res-offsite', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        var rates = data.defaults || {
            listing_fee: 0.20,
            transaction_rate: 0.065,
            offsite_ads: { no:0, '12':0.12, '15':0.15 },
            processing: { etsy_direct_checkout: 0.0365833333333333, paypal: 0.0358333333333333 }
        };

        function setDisabledState(disabled){
            inputs.forEach(function(i){ if(i){ i.disabled = disabled; } });
            if(disabled){ root.classList.add('etsy-disabled'); results.style.display = 'none'; }
            else { root.classList.remove('etsy-disabled'); results.style.display = 'block'; }
        }

        // restore email state
        var savedEmail = localStorage.getItem('etsy_email') || '';
        var confirmed = localStorage.getItem('etsy_email_confirmed') === '1';
        if(savedEmail){ email.value = savedEmail; }
        if(confirmed && savedEmail){ confirmBtn.textContent = '✔ Email Confirmed'; confirmBtn.disabled = true; setDisabledState(false); }
        else { setDisabledState(true); }

        confirmBtn.addEventListener('click', function(){
            var val = email.value.trim();
            if(!val || !/\S+@\S+\.\S+/.test(val)){
                alert('Please enter a valid email to continue');
                return;
            }
            confirmBtn.textContent = '✔ Email Confirmed';
            confirmBtn.disabled = true;
            localStorage.setItem('etsy_email', val);
            localStorage.setItem('etsy_email_confirmed', '1');
            setDisabledState(false);
            calculate();
        });

        clearBtn.addEventListener('click', function(){
            email.value = '';
            confirmBtn.textContent = 'Confirm Email';
            confirmBtn.disabled = false;
            localStorage.removeItem('etsy_email');
            localStorage.removeItem('etsy_email_confirmed');
            inputs.forEach(function(i){ if(i){ if(i.type === 'checkbox') i.checked = false; else i.value = ''; } });
            setDisabledState(true);
            [resListing,resTransaction,resProcessing,resOffsite,resTotal,resEarnings,resProfit,resMargin].forEach(function(el){ el.textContent='-'; el.classList.remove('positive','negative'); });
        });

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var item = parseFloat(qs('#etsy-item-price', root).value) || 0;
            var itemCost = parseFloat(qs('#etsy-item-cost', root).value) || 0;
            var shippingCharges = parseFloat(qs('#etsy-shipping-charges', root).value) || 0;
            var shippingCost = parseFloat(qs('#etsy-shipping-cost', root).value) || 0;
            var paymentMethod = (qs('#etsy-payment-method', root).value || 'Etsy Direct Checkout');
            var offsite = (qs('#etsy-offsite-ads', root).value || 'No');
            var buyerLocation = (qs('#etsy-buyer-location', root).value || 'Local');
            var salesTax = parseFloat(qs('#etsy-sales-tax', root).value) || 0;
            var giftWrap = parseFloat(qs('#etsy-gift-wrap', root).value) || 0;

            // currency symbol default
            var currency = '$';

            var base = item + shippingCharges; // used for transaction, processing, offsite

            // listing fee fixed
            var listingFee = parseFloat(rates.listing_fee) || 0.20;

            // transaction fee 6.5% on (item + shipping charges)
            var transactionFee = Number((base * (rates.transaction_rate || 0.065)).toFixed(2));

            // offsite ads
            var offsiteRate = 0;
            if(offsite === '12%') offsiteRate = 0.12;
            else if(offsite === '15%') offsiteRate = 0.15;
            var offsiteFee = offsiteRate > 0 ? Number((base * offsiteRate).toFixed(2)) : 0;

            // processing fee based on payment method (applied to base: item + shipping charges)
            var procKey = paymentMethod.toLowerCase().indexOf('paypal') !== -1 ? 'paypal' : 'etsy_direct_checkout';
            var procRate = rates.processing && rates.processing[procKey] ? rates.processing[procKey] : 0.0365833333333333;
            var processingFee = Number((base * procRate).toFixed(2));

            // Build totals
            var totalFees = Number((listingFee + transactionFee + processingFee + offsiteFee).toFixed(2));

            // Earnings = base - totalFees
            var earnings = Number((base - totalFees).toFixed(2));

            // Profit = earnings - itemCost - shippingCost - giftWrap
            var profit = Number((earnings - itemCost - shippingCost - giftWrap).toFixed(2));

            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            // populate UI
            resListing.textContent = formatCurrency(listingFee, currency);
            resTransaction.textContent = formatCurrency(transactionFee, currency);
            resProcessing.textContent = formatCurrency(processingFee, currency);
            if(offsiteFee > 0){ resOffsite.textContent = formatCurrency(offsiteFee, currency); resOffsiteRow.style.display = 'flex'; } else { resOffsiteRow.style.display = 'none'; }
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ el.classList.remove('positive','negative'); var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); if(!isNaN(num) && num >= 0) el.classList.add('positive'); else el.classList.add('negative'); });
        }

    });
})();