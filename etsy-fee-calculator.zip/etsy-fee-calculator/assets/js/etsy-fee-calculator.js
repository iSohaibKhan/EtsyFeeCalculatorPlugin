(function(){
    function qs(sel, el) { return (el || document).querySelector(sel); }
    var data = (window.EtsyCalcData && window.EtsyCalcData.rates) ? window.EtsyCalcData.rates : {};

    document.addEventListener('DOMContentLoaded', function(){
        var root = qs('.etsy-calc');
        if(!root) return;

        var inputs = [
            qs('#etsy-item-price', root),
            qs('#etsy-item-cost', root),
            qs('#etsy-shipping-charges', root),
            qs('#etsy-shipping-cost', root),
            qs('#etsy-payment-method', root),
            qs('#etsy-offsite-ads', root),
            qs('#etsy-buyer-location', root),
            qs('#etsy-sales-tax', root),
            qs('#etsy-gift-wrap', root)
        ];

        var results = qs('#etsy-results', root);
        var resListing = qs('#res-listing', root);
        var resTransaction = qs('#res-transaction', root);
        var resProcessing = qs('#res-processing', root);
        var resOffsiteRow = qs('#res-offsite-row', root);
        var resOffsite = qs('#res-offsite', root);
        var resTotal = qs('#res-total', root);
        var resEarnings = qs('#res-earnings', root);
        var resProfit = qs('#res-profit', root);
        var resMargin = qs('#res-margin', root);

        var rates = data.defaults || {
            listing_fee: 0.20,
            transaction_rate: 0.065,
            offsite_ads: { no:0, '12':0.12, '15':0.15 },
            processing: { etsy_direct_checkout: 0.0365833333333333, paypal: 0.0358333333333333 }
        };

        // fields always enabled
        results.style.display = 'block';

        inputs.forEach(function(i){ if(!i) return; i.addEventListener('input', calculate); i.addEventListener('change', calculate); });

        function formatCurrency(val, symbol){
            if(isNaN(val)) return '-';
            var fixed = Number(val).toFixed(2);
            return symbol + fixed;
        }

        function calculate(){
            var item = parseFloat(qs('#etsy-item-price', root).value) || 0;
            var itemCost = parseFloat(qs('#etsy-item-cost', root).value) || 0;
            var shippingCharges = parseFloat(qs('#etsy-shipping-charges', root).value) || 0;
            var shippingCost = parseFloat(qs('#etsy-shipping-cost', root).value) || 0;
            var paymentMethod = (qs('#etsy-payment-method', root).value || 'Etsy Direct Checkout');
            var offsite = (qs('#etsy-offsite-ads', root).value || 'No');
            var salesTax = parseFloat(qs('#etsy-sales-tax', root).value) || 0;
            var giftWrap = parseFloat(qs('#etsy-gift-wrap', root).value) || 0;

            var currency = '$';
            var base = item + shippingCharges;

            var listingFee = parseFloat(rates.listing_fee) || 0.20;
            var transactionFee = Number((base * (rates.transaction_rate || 0.065)).toFixed(2));

            var offsiteRate = 0;
            if(offsite === '12%') offsiteRate = 0.12;
            else if(offsite === '15%') offsiteRate = 0.15;
            var offsiteFee = offsiteRate > 0 ? Number((base * offsiteRate).toFixed(2)) : 0;

            var procKey = paymentMethod.toLowerCase().indexOf('paypal') !== -1 ? 'paypal' : 'etsy_direct_checkout';
            var procRate = rates.processing && rates.processing[procKey] ? rates.processing[procKey] : 0.0365833333333333;
            var processingFee = Number((base * procRate).toFixed(2));

            var totalFees = Number((listingFee + transactionFee + processingFee + offsiteFee).toFixed(2));
            var earnings = Number((base - totalFees).toFixed(2));
            var profit = Number((earnings - itemCost - shippingCost - giftWrap).toFixed(2));
            var margin = 0;
            if(earnings !== 0){ margin = Number(((profit / earnings) * 100).toFixed(1)); }

            resListing.textContent = formatCurrency(listingFee, currency);
            resTransaction.textContent = formatCurrency(transactionFee, currency);
            resProcessing.textContent = formatCurrency(processingFee, currency);
            if(offsiteFee > 0){ resOffsite.textContent = formatCurrency(offsiteFee, currency); resOffsiteRow.style.display = 'flex'; } else { resOffsiteRow.style.display = 'none'; }
            resTotal.textContent = formatCurrency(totalFees, currency);
            resEarnings.textContent = formatCurrency(earnings, currency);
            resProfit.textContent = formatCurrency(profit, currency);
            resMargin.textContent = margin + '%';

            [resEarnings,resProfit].forEach(function(el){ 
                el.classList.remove('positive','negative'); 
                var num = parseFloat(el.textContent.replace(/[^0-9.-]+/g,'')); 
                if(!isNaN(num) && num >= 0) el.classList.add('positive'); 
                else el.classList.add('negative'); 
            });
        }

    });
})();
